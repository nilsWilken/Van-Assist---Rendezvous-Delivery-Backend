position = "Traci Instance needs to start first"
step = 0
startSimulationWasCalledFirst=False
simulationIsRunning=False
stopSimulation=False
parkingAreasAreLoading=False
parkingAreaList=[]
driveToNextParkingAreaWasCalled=False
